document.getElementById("btn-navbar").addEventListener("click", () => {
  const menu = document.getElementById("id_ul_navbar");
  menu.classList.toggle("active");
});
